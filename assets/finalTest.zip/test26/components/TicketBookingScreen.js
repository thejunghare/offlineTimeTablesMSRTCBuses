import React, { useState } from 'react';
import {
  ScrollView,
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Linking,
  TouchableWithoutFeedback, // import TouchableWithoutFeedback
  Keyboard, // import Keyboard
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { Input, Button, Text } from 'react-native-elements';
// import stripe from 'tipsi-stripe';

const TicketBookingScreen = () => {
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [adults, setAdults] = useState('');
  const [teenagers, setTeenagers] = useState('');
  const [totalPrice, setTotalPrice] = useState('');
  const [women, setWomen] = useState('');

  const fares = {
    Satara: {
      'Samartha mandir': { adults: 10, women: 9, teenagers: 8 },
      'Dnyanshree college': { adults: 11, women: 10, teenagers: 9 },
      Sajjangad: { adults: 25, women: 10, teenagers: 6 },
    },
    'San Francisco': {
      'New York': { adults: 10, women: 9, teenagers: 8 },
      'Los Angeles': { adults: 11, women: 10, teenagers: 9 },
      Chicago: { adults: 8, women: 7, teenagers: 6 },
    },
  };

  const handleSourceChange = (value) => {
    setSource(value);
  };

  const handleDestinationChange = (value) => {
    setDestination(value);
  };

  const handleAdultsChange = (value) => {
    setAdults(value);
  };

  const handleTeenagersChange = (value) => {
    setTeenagers(value);
  };

  const handleCalculatePrice = () => {
    const fare = fares[source][destination];
    const total =
      fare.adults * Number(adults) +
      fare.women * Number(women) +
      fare.teenagers * Number(teenagers);
    setTotalPrice(total);
  };

  const handleWomenChange = (value) => {
    setWomen(value);
  };

  const handlePayNow = async () => {
    try {
      const token = await stripe.paymentRequestWithCardForm();
      console.log(token);
      // TODO: use the token to process the payment with your backend
    } catch (error) {
      console.log(error);
    }
  };

  const handleReset = () => {
    setSource('');
    setDestination('');
    setAdults('');
    setTeenagers('');
    setTotalPrice('');
  };

  const handlePrivacyPolicy = () => {
    Linking.openURL('https://www.example.com/privacy-policy');
  };

  return (
    <ScrollView>
      <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <View style={styles.container}>
          <View style={styles.pickerContainer}>
            <Picker
              style={{ flex: 1 }}
              selectedValue={source}
              onValueChange={handleSourceChange}>
              <Picker.Item label="Source" value="" />
              <Picker.Item label="Satara" value="Satara" />
              <Picker.Item label="Samartha mandir" value="Samartha mandir" />
              <Picker.Item
                label="Dnyanshree college"
                value="Dnyanshree college"
              />
              <Picker.Item label="Sajjangad" value="Sajjangad" />
            </Picker>
            <Picker
              style={{ flex: 1 }}
              selectedValue={destination}
              onValueChange={handleDestinationChange}>
              <Picker.Item label="Destination" value="" />
              <Picker.Item label="Satara" value="Satara" />
              <Picker.Item label="Samartha mandir" value="Samartha mandir" />
              <Picker.Item
                label="Dnyanshree college"
                value="Dnyanshree college"
              />
              <Picker.Item label="Sajjangad" value="Sajjangad" />
            </Picker>
          </View>
          <View style={styles.inputContainer}>
            <Input
              label="Number of Adults"
              value={adults}
              keyboardType="numeric"
              onChangeText={handleAdultsChange}
            />
            <Input
              label="Number of Teenagers"
              value={teenagers}
              keyboardType="numeric"
              onChangeText={handleTeenagersChange}
            />
            <Input
              label="Number of Women"
              value={women}
              keyboardType="numeric"
              onChangeText={handleWomenChange}
            />
          </View>
          <View style={styles.buttonContainer}>
            <View>
              {/*<Button title="Calculate Price" onPress={handleCalculatePrice} />*/}
              <TouchableOpacity
                style={styles.button}
                onPress={handleCalculatePrice}>
                <Text style={styles.buttonText}>Calculate Price</Text>
              </TouchableOpacity>
              <Text style={styles.totalPrice}>
                Total Payable: ₹{totalPrice}
              </Text>
            </View>
            <View>
              {/* <Button
                title="Pay Now"
                onPress={handlePayNow}
                disabled={!totalPrice}
              /> */}
              <TouchableOpacity style={styles.button} onPress={handlePayNow}>
                <Text style={styles.buttonText}>Pay Now</Text>
              </TouchableOpacity>
            </View>
            <View>
              {/* <Button
                title="Reset"
                onPress={handleReset}
                buttonStyle={{ backgroundColor: 'gray' }}
              /> */}
              <TouchableOpacity
                style={styles.button}
                onPress={handleReset}>
                <Text style={styles.buttonText} buttonStyle={{ backgroundColor: 'gray' }}>RESET</Text>
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity onPress={handlePrivacyPolicy}>
            <Text style={styles.privacyPolicy}>
              By booking, you agree to our Terms and Condition.
            </Text>
          </TouchableOpacity>
        </View>
      </TouchableWithoutFeedback>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f2f2f2',
    minWidth: '100%',
  },
  pickerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'Column',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  privacyPolicy: {
    marginTop: 20,
    textAlign: 'center',
    color: 'black',
  },
  button: {
    marginBottom: 10,
    backgroundColor: '#FF0000',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  totalPrice: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: 'black',
  },
});

export default TicketBookingScreen;
