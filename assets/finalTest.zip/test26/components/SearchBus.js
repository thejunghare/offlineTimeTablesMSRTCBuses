import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal,
} from 'react-native';
import { Card, Icon } from 'react-native-elements';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Picker } from '@react-native-picker/picker';

const SearchBus = () => {
  const [loading, setLoading] = useState(false);
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [buses, setBuses] = useState([]);
  const [noBusesFound, setNoBusesFound] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [routes, setRoutes] = useState([]);
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [showRoutes, setShowRoutes] = useState(false);

  const data = [
    {
      id: 1,
      name: 'Satara - Sajjangad',
      source: 'Satara',
      destination: 'Sajjangad',
      time: '10:00 AM',
      fare: '₹25',
    },
    {
      id: 2,
      name: 'Satara - Sajjangad',
      source: 'Satara',
      destination: 'Sajjangad',
      time: '01:00 PM',
      fare: '₹25',
    },
    {
      id: 3,
      name: 'Satara - Medha -  Mahabaleshwar ',
      source: 'Satara',
      destination: 'Mahabaleshwar',
      time: '08:00 PM',
      fare: '₹45',
    },
    {
      id: 4,
      name: 'Satara - Wai - Mahabaleshwar',
      source: 'Satara',
      destination: 'Mahabaleshwar',
      time: '08:00 PM',
      fare: '₹45',
    },
    {
      id: 5,
      name: 'Satara - lonavala - Mumbai',
      source: 'Satara',
      destination: 'Mumbai',
      time: '08:00 PM',
      fare: '₹45',
    },
    // Swargate - satara
    {
      id: 6,
      name: 'Swargate - satara',
      source: 'Swargate',
      destination: 'satara',
      time: '06:00 AM',

      fare: '₹160',
    },
    {
      id: 7,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '08:40 AM',
      fare: '₹160',
    },
    {
      id: 8,
      name: 'Swargate - satara',
      source: 'Swargate',
      destination: 'satara',
      time: '11:00 AM',

      fare: '₹160',
    },
    {
      id: 9,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '03:00 PM',
      fare: '₹160',
    },
    {
      id: 10,
      name: 'Swargate - satara',
      source: 'Swargate',
      destination: 'satara',
      time: '05:40 PM',

      fare: '₹160',
    },
    {
      id: 11,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '08:00 PM',
      fare: '₹160',
    },
    {
      id: 12,
      name: 'Swargate - satara',
      source: 'Swargate',
      destination: 'satara',
      time: '06:20 AM',

      fare: '₹160',
    },
    {
      id: 13,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '09:00 AM',
      fare: '₹160',
    },
    {
      id: 14,
      name: 'Swargate - satara',
      source: 'Swargate',
      destination: 'satara',
      time: '11:20 AM',

      fare: '₹160',
    },
    {
      id: 15,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '03:20 PM',
      fare: '₹160',
    },
    {
      id: 16,
      name: 'Swargate - satara',
      source: 'Swargate',
      destination: 'satara',
      time: '06:00 PM',

      fare: '₹160',
    },
    {
      id: 17,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '08:20 PM',
      fare: '₹160',
    },
    // Swargate - Satara
    {
      id: 18,
      name: 'Swargate - satara',
      source: 'Swargate',
      destination: 'satara',
      time: '06:40 AM',

      fare: '₹160',
    },
    //Satara - Swargate
    {
      id: 19,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '09:20 AM',
      fare: '₹160',
    }, //Satara - Swargate
    {
      id: 20,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '09:20 AM',
      fare: '₹160',
    }, //Satara - Swargate
    {
      id: 21,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '09:20 AM',
      fare: '₹160',
    },

    // Swargate - Satara
    {
      id: 22,
      name: 'Swargate - satara',
      source: 'Swargate',
      destination: 'satara',
      time: '06:20 PM',
      fare: '₹160',
    },
    //Satara - Swargate
    {
      id: 23,
      name: 'Satara - Swargate',
      source: 'Satara',
      destination: 'Swargate',
      time: '08:40 PM',
      fare: '₹160',
    }, //Satara - Dusaale
    {
      id: 24,
      name: 'Satara - Dusaale',
      source: 'Satara',
      destination: 'Dusaale',
      time: '01:00 PM',
      fare: '₹60',
    },
    //Satara - Tarale
    {
      id: 25,
      name: 'Satara - Tarale',
      source: 'Satara',
      destination: 'Tarale',
      time: '04:00 PM',
      fare: '₹55',
    }, //Tarale - Satara
    {
      id: 26,
      name: 'Tarale - Satara',
      source: 'Tarale',
      destination: 'Satara',
      time: '06:05 PM',
      fare: '₹55',
    },

    //Satara - Dusaale
    {
      id: 27,
      name: 'Satara - Dusaale',
      source: 'Satara',
      destination: 'Dusaale',
      time: '07:30 PM',
      fare: '₹60',
    },
    //Dusaale - Satara
    {
      id: 28,
      name: 'Dusaale - Satara',
      source: 'Dusaale',
      destination: 'Satara',
      time: '07:00 AM',
      fare: '₹60',
    },
    //Satara - Dusaale
    {
      id: 29,
      name: 'Satara - Dusaale',
      source: 'Satara',
      destination: 'Dusaale',
      time: '08:40 AM',
      fare: '₹60',
    },
    //Dusaale - Satara
    {
      id: 30,
      name: 'Dusaale - Satara',
      source: 'Dusaale',
      destination: 'Satara',
      time: '10:20 AM',
      fare: '₹60',
    },
    //Satara - Limb
    {
      id: 31,
      name: 'Satara - Limb',
      source: 'Satara',
      destination: 'Limb',
      time: '12:30 PM',
      fare: '₹25',
    },
    //Limb - Satara
    {
      id: 32,
      name: 'Limb - Satara',
      source: 'Limb',
      destination: 'Satara',
      time: '01:10 PM',
      fare: '₹25',
    },
    //Satara - Malganv
    {
      id: 33,
      name: 'Satara - Malganv',
      source: 'Satara',
      destination: 'Malganv',
      time: '12:30 PM',
      fare: '₹25',
    },
    //Malganv - Satara
    {
      id: 34,
      name: 'Malganv - Satara',
      source: 'Malganv',
      destination: 'Satara',
      time: '02:55 PM',
      fare: '₹25',
    },
    //Satara - Malganv
    {
      id: 35,
      name: 'Satara - Malganv',
      source: 'Satara',
      destination: 'Malganv',
      time: '03:45 PM',
      fare: '₹25',
    },
    //Malganv - Satara
    {
      id: 36,
      name: 'Malganv - Satara',
      source: 'Malganv',
      destination: 'Satara',
      time: '06:35 PM',
      fare: '₹25',
    },
    //Satara - Kholwadi
    {
      id: 37,
      name: 'Satara - Kholwadi',
      source: 'Satara',
      destination: 'Kholwadi',
      time: '05:25 PM',
      fare: '₹30',
    },
    //Kholwadi - Satara
    {
      id: 38,
      name: 'Kholwadi - Satara',
      source: 'Kholwadi',
      destination: 'Satara',
      time: '06:20 PM',
      fare: '₹30',
    },
    //Satara - Kholwadi
    {
      id: 39,
      name: 'Satara - Kholwadi',
      source: 'Satara',
      destination: 'Kholwadi',
      time: '05:25 PM',
      fare: '₹30',
    },
    //Satara -Rautwadi'
    {
      id: 40,
      name: 'Satara - Rautwadi',
      source: 'Satara',
      destination: 'Rautwadi',
      time: '07:15 PM',
      fare: '₹30',
    },
    //Rautwadi' - Satara
    {
      id: 41,
      name: 'Rautwadi' - 'Satara',
      source: 'Rautwadi',
      destination: 'Satara',
      time: '08:10 PM',
      fare: '₹30',
    },
    //Satara - Limb
    {
      id: 42,
      name: 'Satara - Limb',
      source: 'Satara',
      destination: 'Limb',
      time: '05:50 AM',
      fare: '₹25',
    },
    //Limb - Satara
    {
      id: 43,
      name: 'Limb - Satara',
      source: 'Limb',
      destination: 'Satara',
      time: '06:30 AM',
      fare: '₹25',
    },
    {
      // Lavanghar
      id:44,
      name: ' Lavanghar - Satara',
      source: 'Lavanghar ',
      destination: 'Satara',
      time: '12:40 PM',
      fare: '₹25',
    },
    {
      // railway
      id: 45,
      name: 'BusStation - RailwayStation',
      source: 'Satara ',
      destination: 'RailwayStation',
      time: '14:00 PM',
      fare: '₹15',
    },
    {
      // railway
      id: 46,
      name: ' RailwayStation-Rajwada',
      source: 'RailwayStation ',
      destination: 'Rajwada',
      time: '02:40 PM',
      fare: '₹20',
    },
    {
      id: 47,
      name: 'Rajwada- Mahagaon',
      source: 'Rajwada ',
      destination: 'Mahagaon',
      time: '03:15 PM',
      fare: '₹25',
    },
    {
      // Mahagaon-Rajwada
      id: 48,
      name: 'Mahagaon-Rajwada',
      source: 'Mahagaon ',
      destination: 'Rajwada',
      time: '03:55 PM',
      fare: '₹25',
    },
    {
      // Rajwada-Pharmacy
      id: 49,
      name: 'Rajwada-Pharmacy',
      source: 'Rajwada ',
      destination: 'Pharmacy',
      time: '04:35 PM',
      fare: '₹25',
    },
    {
      // Rajwada-Pharmacy
      id: 50,
      name: 'Pharmacy-Rajwada',
      source: 'Pharmacy ',
      destination: 'Rajwada',
      time: '05:10 PM',
      fare: '₹25',
    },
    {
      // Rajwada-Divya Nagar
      id: 51,
      name: 'Rajwada-DivyaNagar',
      source: 'Rajwada ',
      destination: 'DivyaNagar',
      time: '05:45 PM',
      fare: '₹10',
    },
    {
      // Rajwada-Divya Nagar
      id: 52,
      name: 'DivyaNagar-Rajwada',
      source: 'DivyaNagar ',
      destination: 'Rajwada',
      time: '06:05 PM',
      fare: '₹10',
    },
    {
      // Rajwada-Divya Nagar
      id: 53,
      name: 'Rajwada-DivyaNagar',
      source: 'Rajwada ',
      destination: 'DivyaNagar',
      time: '05:45 PM',
      fare: '₹10',
    },
    {
      // Rajwada-Mahagaon
      id: 54,
      name: 'Rajwada-Mahagaon',
      source: 'Rajwada ',
      destination: 'Mahagaon',
      time: '06:25 PM',
      fare: '₹25',
    },
    {
      // Mahagaon-Satara
      id: 55,
      name: 'Mahagaon-Satara',
      source: 'Mahagaon ',
      destination: 'Satara',
      time: '07:05 PM',
      fare: '₹20',
    },
    {
      // Satara-Aredare
      id: 56,
      name: 'Satara-Aredare',
      source: 'Satara ',
      destination: 'Aredare',
      time: '08:00 PM',
      fare: '₹25',
    },
    {
      // Satara-Aredare
      id: 57,
      name: 'Aredare-Satara',
      source: 'Aredare ',
      destination: 'Satara',
      time: '08:40 PM',
      fare: '₹25',
    },
    {
      // Satara-Mandave
      id: 58,
      name: 'Satara-Mandave',
      source: 'Satara ',
      destination: 'Mandave',
      time: '05:45 AM',
      fare: '₹45',
    },
    {
      // Satara-Mandave
      id: 59,
      name: 'Mandave-Satara',
      source: 'Mandave',
      destination: 'Satara',
      time: '07:05 AM',
      fare: '₹45',
    },
    {
      // Satara-Padali
      id: 60,
      name: 'Satara-Padali',
      source: 'Satara',
      destination: 'Padali',
      time: '09:00 AM',
      fare: '₹35',
    },
    {
      // Satara-Padali
      id: 61,
      name: 'Satara-Padali',
      source: 'Padali',
      destination: 'Satara',
      time: '09:50 AM',
      fare: '₹35',
    },

    {
      // Satara-Mandave
      id: 62,
      name: 'Satara-Mandave',
      source: 'Satara ',
      destination: 'Mandave',
      time: '11:30 AM',
      fare: '₹45',
    },
    {
      // Satara-Mandave
      id: 63,
      name: 'Mandave-Satara',
      source: 'Mandave',
      destination: 'Satara',
      time: '12:40 PM',
      fare: '₹45',
    },

    {
      // railway
      id: 64,
      name: 'BusStation - RailwayStation',
      source: 'Satara ',
      destination: 'RailwayStation',
      time: '02:50 PM',
      fare: '₹15',
    },
    {
      // railway
      id:65,
      name: ' RailwayStation-Rajwada',
      source: 'RailwayStation ',
      destination: 'Rajwada',
      time: '03:25 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 66,
      name: ' Rajwada-RailwayStation',
      source: 'Rajwada ',
      destination: 'RailwayStation',
      time: '04:00 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 67,
      name: ' RailwayStation-Rajwada',
      source: 'RailwayStation ',
      destination: 'Rajwada',
      time: '04:35 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 68,
      name: ' Rajwada-RailwayStation',
      source: 'Rajwada ',
      destination: 'RailwayStation',
      time: '06:00 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 69,
      name: ' RailwayStation-Rajwada',
      source: 'RailwayStation ',
      destination: 'Rajwada',
      time: '06:45 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 70,
      name: ' Rajwada-RailwayStation',
      source: 'Rajwada ',
      destination: 'RailwayStation',
      time: '07:20 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 71,
      name: ' RailwayStation-Rajwada',
      source: 'RailwayStation ',
      destination: 'Rajwada',
      time: '07:55 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 72,
      name: ' Rajwada-RailwayStation',
      source: 'Rajwada ',
      destination: 'RailwayStation',
      time: '09:00 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 73,
      name: ' RailwayStation-Rajwada',
      source: 'RailwayStation ',
      destination: 'Rajwada',
      time: '09:55 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 74,
      name: ' Rajwada-RailwayStation',
      source: 'Rajwada ',
      destination: 'RailwayStation',
      time: '10:40 PM',
      fare: '₹20',
    },
    {
      // railway
      id: 75,
      name: ' RailwayStation-Rajwada',
      source: 'RailwayStation ',
      destination: 'Rajwada',
      time: '11:30 PM',
      fare: '₹20',
    },
    {
      // Satara-Jambhe
      id: 76,
      name: ' Satara-Jambhe ',
      source: 'Satara ',
      destination: 'Jambhe',
      time: '06:00 AM',
      fare: '₹60',
    },
    {
      // Satara-Jambhe
      id: 77,
      name: ' Jambhe-Satara ',
      source: 'Jambhe ',
      destination: 'Satara',
      time: '07:40 AM',
      fare: '₹60',
    },

    {
      // Satara-      Chinchani

      id: 78,
      name: ' Satara-Chinchani',
      source: 'Satara',
      destination: 'Chinchani',
      time: '09:40 AM',
      fare: '₹45',
    },
    {
      // Satara-      Chinchani

      id: 79,
      name: ' Chinchani-Satara',
      source: 'Chinchani',
      destination: 'Satara',
      time: '10:45 AM',
      fare: '₹45',
    },

    {
      // Satara-Raighar

      id: 80,
      name: ' Satara-Raighar',
      source: 'Satara',
      destination: 'Raighar',
      time: '12:00 PM',
      fare: '₹30',
    },
    {
      // Satara-Raighar

      id: 81,
      name: 'Raighar-Satara',
      source: 'Raighar',
      destination: 'Satara',
      time: '12:50 PM',
      fare: '₹30',
    },

    {
      // Satara-Rajwada

      id: 82,
      name: ' Satara-Rajwada',
      source: 'Satara',
      destination: 'Rajwada',
      time: '01:40 PM',
      fare: '₹10',
    },
    {
      // Rajwada-Umbraj

      id: 83,
      name: ' Rajwada-Umbraj',
      source: 'Rajwada',
      destination: 'Umbraj',
      time: '02:00 PM',
      fare: '₹55',
    },
    {
      // Rajwada-Umbraj

      id: 84,
      name: ' Umbraj-Rajwada',
      source: 'Umbraj',
      destination: 'Rajwada',
      time: '03:15 PM',
      fare: '₹55',
    },
    {
      // Rajwada-Umbraj

      id: 85,
      name: ' Rajwada-Umbraj',
      source: 'Rajwada',
      destination: 'Umbraj',
      time: '04:30 PM',
      fare: '₹55',
    },
    {
      // Rajwada-Umbraj

      id: 86,
      name: ' Umbraj-Rajwada',
      source: 'Umbraj',
      destination: 'Rajwada',
      time: '05:45 PM',
      fare: '₹55',
    },

    {
      // Rajwada-Nagthane

      id: 87,
      name: 'Rajwada-Nagthane',
      source: 'Rajwada',
      destination: 'Nagthane',
      time: '07:15 PM',
      fare: '₹25',
    },
    {
      // Nagthane-Satara

      id: 88,
      name: 'Nagthane-Satara',
      source: 'Nagthane',
      destination: 'Satara',
      time: '08:00 PM',
      fare: '₹25',
    },

    {
      // Satara-Kusawade

      id: 89,
      name: ' Satara-Kusawade',
      source: 'Satara',
      destination: 'Kusawade',
      time: '05:40 AM',
      fare: '₹25',
    },
    {
      // Satara-Kusawade

      id: 90,
      name: 'Kusawade-Satara',
      source: 'Kusawade',
      destination: 'Satara',
      time: '06:30 AM',
      fare: '₹25',
    },

    {
      // Satara-Yerunkawadi

      id:91,
      name: ' Satara-YerunkarWadi',
      source: 'Satara',
      destination: 'YerunkarWadi',
      time: '07:20 AM',
      fare: '₹35',
    },
    {
      // Satara-Yerunkawadi

      id: 92,
      name: 'YerunkarWadi-Satara',
      source: 'YerunkarWadi',
      destination: 'Satara',
      time: '08:20 AM',
      fare: '₹35',
    },

    {
      // Satara-Kusawade

      id: 93,
      name: ' Satara-Kusawade',
      source: 'Satara',
      destination: 'Kusawade',
      time: '09:45 AM',
      fare: '₹25',
    },
    {
      // Satara-Kusawade

      id: 94,
      name: 'Kusawade-Satara',
      source: 'Kusawade',
      destination: 'Satara',
      time: '10:30 AM',
      fare: '₹25',
    },
    {
      // Satara-Rahimatpur

      id: 95,
      name: ' Satara-Rahimatpur',
      source: 'Satara',
      destination: 'Rahimatpur',
      time: '11:30 AM',
      fare: '₹45',
    },
    {
      // Satara-Rahimatpur

      id: 96,
      name: 'Rahimatpur-Satara',
      source: 'Rahimatpur',
      destination: 'Satara',
      time: '12:30 PM',
      fare: '₹45',
    },

    {
      // Satara- Borkhal

      id: 97,
      name: ' Satara- Borkhal',
      source: 'Satara',
      destination: ' Borkhal',
      time: '05:30 AM',
      fare: '₹25',
    },
    {
      // Satara- Borkhal

      id: 98,
      name: ' Borkhal-Satara',
      source: ' Borkhal',
      destination: 'Satara',
      time: '06:05 AM',
      fare: '₹25',
    },

    {
      // Satara-Mahagaon
      id: 99,
      name: 'Satara-Mahagaon',
      source: 'Satara ',
      destination: 'Mahagaon',
      time: '06:40 AM',
      fare: '₹15',
    },

    {
      // Mahagaon-Rajwada
      id: 100,
      name: 'Mahagaon-Rajwada',
      source: ' Mahagaon',
      destination: 'Rajwada',
      time: '07:05 AM',
      fare: '₹20',
    },
    {
      // Rajwada- Borkhal

      id: 101,
      name: ' Rajwada- Borkhal',
      source: 'Rajwada',
      destination: ' Borkhal',
      time: '08:05 AM',
      fare: '₹25',
    },
    {
      // Satara- Borkhal

      id: 102,
      name: ' Borkhal-Satara',
      source: ' Borkhal',
      destination: 'Satara',
      time: '08:50 AM',
      fare: '₹25',
    },

    {
      // Satara- Dmart

      id: 103,
      name: ' Satara- Dmart',
      source: 'Satara',
      destination: ' Dmart',
      time: '09:30 AM',
      fare: '₹15',
    },
    {
      // Satara- dmart

      id: 104,
      name: ' Dmart-Satara',
      source: ' Dmarrt',
      destination: 'Satara',
      time: '10:00 AM',
      fare: '₹15',
    },
    {
      // Satara-Mahagaon
      id: 105,
      name: 'Satara-Mahagaon',
      source: 'Satara ',
      destination: 'Mahagaon',
      time: '11:40 AM',
      fare: '₹15',
    },
    {
      // Satara-Aredare
      id: 106,
      name: 'Satara-Aredare',
      source: 'Satara ',
      destination: 'Aredare',
      time: '11:45 AM',
      fare: '₹25',
    },

    {
      // Satara-Aredare
      id: 107,
      name: 'Aredare-Satara',
      source: 'Aredare ',
      destination: 'Satara',
      time: '12:25 PM',
      fare: '₹25',
    },

    {
      // Satara-Nigadi
      id: 108,
      name: 'Satara-Nigadi',
      source: 'Satara ',
      destination: 'Nigadi',
      time: '01:10 PM',
      fare: '₹25',
    },

    {
      // Satara-Nigadi
      id: 109,
      name: 'Nigadi-Satara',
      source: 'Nigadi ',
      destination: 'Satara',
      time: '01:50 PM',
      fare: '₹25',
    },

    {
      // Satara-Dahigaon
      id: 110,
      name: 'Satara-Dahigaon',
      source: 'Satara ',
      destination: 'Dahigaon',
      time: '02:30 PM',
      fare: '₹15',
    },
    {
      // Dahigaon-rajwada
      id: 111,
      name: 'Dahigaon-Rajwada',
      source: 'Dahigaon ',
      destination: 'Rajwada',
      time: '02:55 PM',
      fare: '₹20',
    },

    {
      // Rajwada- Borkhal

      id: 112,
      name: ' Rajwada- Borkhal',
      source: 'Rajwada',
      destination: ' Borkhal',
      time: '04:15 PM',
      fare: '₹25',
    },

    {
      // Satara- Borkhal

      id: 113,
      name: ' Borkhal-Satara',
      source: ' Borkhal',
      destination: 'Satara',
      time: '05:05 PM',
      fare: '₹25',
    },

    {
      // Satara-Aredare
      id: 114,
      name: 'Satara-Aredare',
      source: 'Satara ',
      destination: 'Aredare',
      time: '05:40 PM',
      fare: '₹25',
    },

    {
      // Satara-Aredare
      id: 115,
      name: 'Aredare-Satara',
      source: 'Aredare ',
      destination: 'Satara',
      time: '06:20 PM',
      fare: '₹25',
    },

    {
      // Satara-Dhawadshi
      id: 116,
      name: 'Satara-Dhawadshi',
      source: 'Satara ',
      destination: 'Dhawadshi',
      time: '07:00 PM',
      fare: '₹25',
    },

    {
      // Satara-Dhawadshi
      id: 117,
      name: 'Dhawadshi-Satara',
      source: 'Dhawadshi ',
      destination: 'Satara',
      time: '07:35 PM',
      fare: '₹25',
    },
    // page 29
    {
      // SataraBusstation-Rajwada
      id: 118,
      name: 'Satara-Rajwada',
      source: 'Satara ',
      destination: 'Rajwada',
      time: '05:40 AM',
      fare: '₹10',
    },

    {
      // Rajwada-Umbraj

      id:119,
      name: ' Rajwada-Umbraj',
      source: 'Rajwada',
      destination: 'Umbraj',
      time: '06:00 AM',
      fare: '₹55',
    },
    {
      // Rajwada-Umbraj

      id: 120,
      name: ' Umbraj-Rajwada',
      source: 'Umbraj',
      destination: 'Rajwada',
      time: '07:10 AM',
      fare: '₹55',
    },

    {
      // Rajwada-Umbraj

      id: 121,
      name: ' Rajwada-Umbraj',
      source: 'Rajwada',
      destination: 'Umbraj',
      time: '08:20 AM',
      fare: '₹55',
    },
    {
      // Rajwada-Umbraj

      id: 122,
      name: ' Umbraj-Rajwada',
      source: 'Umbraj',
      destination: 'Rajwada',
      time: '09:30 AM',
      fare: '₹55',
    },
    {
      // Rajwada-Umbraj

      id:123,
      name: ' Rajwada-Umbraj',
      source: 'Rajwada',
      destination: 'Umbraj',
      time: '10:40 AM',
      fare: '₹55',
    },
    {
      // Rajwada-Umbraj

      id:124,
      name: ' Umbraj-Rajwada',
      source: 'Umbraj',
      destination: 'Rajwada',
      time: '11:50 AM',
      fare: '₹55',
    },
    {
      // Rajwada-SataraBusstation
      id: 125,
      name: 'Rajwada-Satara',
      source: 'Rajwada ',
      destination: 'Satara',
      time: '01:00 PM',
      fare: '₹10',
    },

    {
      //satara- Borkhal

      id: 126,
      name: ' Satara- Borkhal',
      source: 'Satara',
      destination: ' Borkhal',
      time: '01:30 PM',
      fare: '₹25',
    },
    {
      // Rajwada- Borkhal

      id: 127,
      name: 'Borkhal-Rajwada',
      source: 'Borkhal',
      destination: ' Rajwada',
      time: '02:05 PM',
      fare: '₹25',
    },

    {
      // Rajwada-Nigadi
      id: 128,
      name: 'Rajwada-Nigadi',
      source: 'Rajwada ',
      destination: 'Nigadi',
      time: '02:50 PM',
      fare: '₹25',
    },

    {
      // Rajwada-Nigadi
      id: 129,
      name: 'Nigadi-Rajwada',
      source: 'Nigadi ',
      destination: 'Rajwada',
      time: '03:40 PM',
      fare: '₹25',
    },

    {
      // Rajwada-PMP
      id: 130,
      name: 'Rajwada-PMP',
      source: 'Rajwada ',
      destination: 'PMP',
      time: '04:30 PM',
      fare: '₹20',
    },

    {
      // Rajwada-PMP
      id: 131,
      name: 'PMP-Rajwada',
      source: 'PMP ',
      destination: 'Rajwada',
      time: '05:00 PM',
      fare: '₹20',
    },
    {
      // Rajwada-Swaminathnagar
      id: 132,
      name: 'Rajwada-Swaminathnagar',
      source: 'Rajwada ',
      destination: 'Swaminathnagar',
      time: '05:30 PM',
      fare: '₹20',
    },
    {
      // -Swaminathnagar- satara
      id: 133,
      name: 'Swaminathnagar-Satara',
      source: 'Swaminathnagar ',
      destination: 'Satara',
      time: '06:05 PM',
      fare: '₹20',
    },

    {
      //satara- Gavadi

      id: 134,
      name: ' Satara- Gavadi',
      source: 'Satara',
      destination: ' Gavadi',
      time: '07:10 PM',
      fare: '₹20',
    },
    {
      // Satara- Gavadi

      id: 135,
      name: 'Gavadi-Satara',
      source: 'Gavadi',
      destination: ' Satara',
      time: '07:40 PM',
      fare: '₹20',
    },

    {
      // Satara-Nigadi
      id: 136,
      name: 'Satara-Nigadi',
      source: 'Satara ',
      destination: 'Nigadi',
      time: '06:10 AM',
      fare: '₹25',
    },

    {
      // Rajwada-Nigadi
      id: 137,
      name: 'Nigadi-Rajwada',
      source: 'Nigadi ',
      destination: 'Rajwada',
      time: '06:50 AM',
      fare: '₹25',
    },
    {
      // SataraBusstation-Rajwada
      id: 138,
      name: 'Rajwada-Satara',
      source: 'Rajwada ',
      destination: 'Satara',
      time: '07:40 AM',
      fare: '₹10',
    },

    {
      // Satara-Dhawadshi
      id: 139,
      name: 'Satara-Dhawadshi',
      source: 'Satara ',
      destination: 'Dhawadshi',
      time: '07:55 AM',
      fare: '₹25',
    },

    {
      // Satara-Dhawadshi
      id: 140,
      name: 'Dhawadshi-Satara',
      source: 'Dhawadshi ',
      destination: 'Satara',
      time: '08:30 PM',
      fare: '₹25',
    },
    {
      // Satara-Swaminathnagar
      id: 141,
      name: 'Satara-Swaminathnagar',
      source: 'Satara ',
      destination: 'Swaminathnagar',
      time: '09:05 AM',
      fare: '₹20',
    },

    {
      // -Swaminathnagar- Rajwada
      id: 142,
      name: 'Swaminathnagar-Rajwada',
      source: 'Swaminathnagar ',
      destination: 'Rajwada',
      time: '09:30 AM',
      fare: '₹20',
    },
    {
      // Rajwada- Borkhal

      id: 143,
      name: ' Rajwada- Borkhal',
      source: 'Rajwada',
      destination: ' Borkhal',
      time: '10:05 AM',
      fare: '₹25',
    },
    {
      // Rajwada- Borkhal

      id: 144,
      name: 'Borkhal-Rajwada',
      source: 'Borkhal',
      destination: ' Rajwada',
      time: '10:50 AM',
      fare: '₹25',
    },
    {
      // Rajwada- Dahigaon

      id: 145,
      name: ' Rajwada- Dahigaon',
      source: 'Rajwada',
      destination: ' Dahigaon',
      time: '12:00 PM',
      fare: '₹25',
    },
  ];

  const handleSearch = () => {
    setLoading(true);

    const filteredData = data.filter(
      (item) =>
        item.source.toLowerCase() === source.toLowerCase() &&
        item.destination.toLowerCase() === destination.toLowerCase()
    );

    const uniqueRoutes = Array.from(
      new Set(filteredData.map((item) => item.name))
    );

    setSelectedRoute(null);
    setBuses([]);
    setShowRoutes(true);
    setRoutes(uniqueRoutes);
    setNoBusesFound(false);
    setCurrentIndex(0);
    setLoading(false);
  };

  const handleRouteSelect = (route) => {
    const filteredData = data.filter((item) => item.name === route);
    if (filteredData.length === 0) {
      setNoBusesFound(true);
      setBuses([]);
    } else {
      setBuses(filteredData);
      setSelectedRoute(route);
      setShowRoutes(false);
      setNoBusesFound(false);
      setCurrentIndex(0);
    }
  };

  const handleNext = () => {
    if (currentIndex < buses.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const renderBuses = () => {
    if (loading) {
      return <Text>Loading...</Text>;
    }

    if (noBusesFound) {
      return <Text>No buses available.</Text>;
    }
    if (buses.length > 0) {
      return (
        <View style={styles.busContainer}>
          <Card containerStyle={styles.cardContainer}>
            <Card.Title style={styles.cardTitle}>{selectedRoute}</Card.Title>
            <Card.Divider />
            <View style={styles.busDetailsContainer}>
              <View style={styles.busDetails}>
                <Text style={styles.busValue}>Source:</Text>
                <Text style={styles.busValue}>
                  {buses[currentIndex].source}
                </Text>
              </View>
              <View style={styles.busDetails}>
                <Text style={styles.busValue}>Destination:</Text>
                <Text style={styles.busValue}>
                  {buses[currentIndex].destination}
                </Text>
              </View>
              <View style={styles.busDetails}>
                <Text style={styles.busValue}>Time:</Text>
                <Text style={styles.busValue}>{buses[currentIndex].time}</Text>
              </View>
              <View style={styles.busDetails}>
                <Text style={styles.busValue}>Fare:</Text>
                <Text style={styles.busValue}>{buses[currentIndex].fare}</Text>
              </View>
            </View>
            <View style={styles.busNavigationContainer}>
              <TouchableOpacity
                style={styles.busNavigationButton}
                onPress={handlePrevious}
                disabled={currentIndex <= 0}>
                <Icon
                  name="chevron-left"
                  type="font-awesome"
                  color="#ffffff"
                  size={20}
                />
              </TouchableOpacity>
              <Text style={styles.busNavigationText}>
                {`${currentIndex + 1}/${buses.length}`}
              </Text>
              <TouchableOpacity
                style={styles.busNavigationButton}
                onPress={handleNext}
                disabled={currentIndex >= buses.length - 1}>
                <Icon
                  name="chevron-right"
                  type="font-awesome"
                  color="#ffffff"
                  size={20}
                />
              </TouchableOpacity>
            </View>
          </Card>
        </View>
      );
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <View style={styles.pickerContainer}>
          <Picker
            style={{ flex: 1 }}
            selectedValue={source}
            onValueChange={setSource}>
            <Picker.Item label="Source" value="" />
            <Picker.Item label="Aredare" value="Aredare" />
            <Picker.Item label="BusStation" value="BusStation" />
            <Picker.Item label="Borkhal" value="Borkhal" />
            <Picker.Item label="Chinchani" value="Chinchani" />
            <Picker.Item label="Dahigaon" value="Dahigaon" />
            <Picker.Item label="Dhawadshi" value="Dhawadshi" />
            <Picker.Item label="Dusaale" value="Dusaale" />
            <Picker.Item label="Dmarrt" value="Dmarrt" />
            <Picker.Item label="Dahigaon" value="Dahigaon" />
            <Picker.Item label="DivyaNagar" value="DivyaNagar" />
            <Picker.Item label="Gavadi" value="Gavadi" />
            <Picker.Item label="Jambhe" value="Jambhe" />
            <Picker.Item label="Kholwadi" value="Kholwadi" />
            <Picker.Item label="Kusawade" value="Kusawade" />
            <Picker.Item label="Limb" value="Limb" />
            <Picker.Item label="Lavanghar" value="Lavanghar" />
            <Picker.Item label="Malganv" value="Malganv" />
            <Picker.Item label="Mahagaon" value="Mahagaon" />
            <Picker.Item label="Mandave" value="Mandave" />
            <Picker.Item label="Mahabaleshwar" value="Mahabaleshwar" />
            <Picker.Item label="Nigadi" value="Nigadi" />
            <Picker.Item label="Nagthane" value="Nagthane" />
            <Picker.Item label="PMP" value="PMP" />
            <Picker.Item label="Padali" value="Padali" />
            <Picker.Item label="Pharmacy" value="Pharmacy" />
            <Picker.Item label="Rajwada" value="Rajwada" />
            <Picker.Item label="Samartha mandir" value="Samartha mandir" />
            <Picker.Item label="Rahimatpur" value="Rahimatpur" />
            <Picker.Item label="Raighar" value="Raighar" />
            <Picker.Item label="Rautwadi" value="Rautwadi" />
            <Picker.Item label="Satara" value="Satara" />
            <Picker.Item label="Swargate" value="Swargate" />
            <Picker.Item label="Swaminathnagar" value="Swaminathnagar" />
            <Picker.Item label="RailwayStation" value="RailwayStation" />
            <Picker.Item label="Sajjangad" value="Sajjangad" />
            <Picker.Item label="Tarale" value="Tarale" />
            <Picker.Item label="Umbraj" value="Umbraj" />
            <Picker.Item label="YerunkarWadi" value="YerunkarWadi" />
          </Picker>

          <Picker
            style={{ flex: 1 }}
            selectedValue={destination}
            onValueChange={setDestination}>
            <Picker.Item label="Source" value="" />
            <Picker.Item label="Aredare" value="Aredare" />
            <Picker.Item label="BusStation" value="BusStation" />
            <Picker.Item label="Borkhal" value="Borkhal" />
            <Picker.Item label="Chinchani" value="Chinchani" />
            <Picker.Item label="Dahigaon" value="Dahigaon" />
            <Picker.Item label="Dhawadshi" value="Dhawadshi" />
            <Picker.Item label="Dusaale" value="Dusaale" />
            <Picker.Item label="Dmarrt" value="Dmarrt" />
            <Picker.Item label="Dahigaon" value="Dahigaon" />
            <Picker.Item label="DivyaNagar" value="DivyaNagar" />
            <Picker.Item label="Gavadi" value="Gavadi" />
            <Picker.Item label="Jambhe" value="Jambhe" />
            <Picker.Item label="Kholwadi" value="Kholwadi" />
            <Picker.Item label="Kusawade" value="Kusawade" />
            <Picker.Item label="Limb" value="Limb" />
            <Picker.Item label="Lavanghar" value="Lavanghar" />
            <Picker.Item label="Malganv" value="Malganv" />
            <Picker.Item label="Mahagaon" value="Mahagaon" />
            <Picker.Item label="Mandave" value="Mandave" />
            <Picker.Item label="Mahabaleshwar" value="Mahabaleshwar" />
            <Picker.Item label="Nigadi" value="Nigadi" />
            <Picker.Item label="Nagthane" value="Nagthane" />
            <Picker.Item label="PMP" value="PMP" />
            <Picker.Item label="Pharmacy" value="Pharmacy" />
            <Picker.Item label="Padali" value="Padali" />
            <Picker.Item label="Rajwada" value="Rajwada" />
            <Picker.Item label="Samartha mandir" value="Samartha mandir" />
            <Picker.Item label="Rahimatpur" value="Rahimatpur" />
            <Picker.Item label="Raighar" value="Raighar" />
            <Picker.Item label="Rautwadi" value="Rautwadi" />
            <Picker.Item label="Satara" value="Satara" />
            <Picker.Item label="Swargate" value="Swargate" />
            <Picker.Item label="Swaminathnagar" value="Swaminathnagar" />
            <Picker.Item label="RailwayStation" value="RailwayStation" />
            <Picker.Item label="Sajjangad" value="Sajjangad" />
            <Picker.Item label="Tarale" value="Tarale" />
            <Picker.Item label="Umbraj" value="Umbraj" />
            <Picker.Item label="YerunkarWadi" value="YerunkarWadi" />
          </Picker>
        </View>
        {/* <TextInput
          style={styles.input}
          placeholder="Source"
          value={source}
          onChangeText={setSource}
        />

        <TextInput
          style={styles.input}
          placeholder="Destination"
          value={destination}
          onChangeText={setDestination}
        />*/}
        {/* <Button title="Search" style={styles.searchBtn} onPress={handleSearch} />*/}
      </View>
      <TouchableOpacity style={styles.searchBtn} onPress={handleSearch}>
        <Text style={styles.searchText}>Search</Text>
      </TouchableOpacity>
      {showRoutes && (
        <ScrollView style={styles.routesContainer}>
          {routes.map((route) => (
            <TouchableOpacity
              key={route}
              style={styles.routeButton}
              onPress={() => handleRouteSelect(route)}>
              <Text style={styles.routeButtonText}>{route}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}
      {renderBuses()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    padding: 16,
  },
  searchBtn: {
    width: '50%',
    backgroundColor: '#FF0000',
    borderRadius: 25,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  searchText: {
    color: 'white',
  },
  pickerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  routeButton: {
    padding: 10,
    marginVertical: 5,
    borderRadius: 5,
    backgroundColor: '#ddd',
  },
  busContainer: {
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  cardContainer: {
    backgroundColor: '#F0F0F0',
    borderRadius: 20,
    borderColor: '#ffffff',
    borderWidth: 1,
    padding: 10,
    shadowColor: '#000000',
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000',
    marginBottom: 10,
  },
  busDetailsContainer: {
    marginBottom: 10,
  },
  busDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  busValue: {
    fontSize: 16,
    color: '#000000',
    marginLeft: 5,
  },
  busNavigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FF0000',
    padding: 10,
    borderRadius: 10,
  },
  busNavigationButton: {
    backgroundColor: '#FF0000',
    borderRadius: 20,
    padding: 10,
  },
  busNavigationText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});

export default SearchBus;
